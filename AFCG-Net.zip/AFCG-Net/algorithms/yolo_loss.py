"""Three-scale anchor assignment, GIoU box loss and BCE classification/objectness."""
import torch
from torch import nn
from torch.nn import functional as F

def xywh_to_xyxy(b):
    x,y,w,h=b.unbind(-1)
    return torch.stack((x-w/2,y-h/2,x+w/2,y+h/2),-1)

def box_iou(a,b):
    lt=torch.maximum(a[...,:2],b[...,:2]);rb=torch.minimum(a[...,2:],b[...,2:])
    wh=(rb-lt).clamp(min=0);inter=wh[...,0]*wh[...,1]
    aa=((a[...,2:]-a[...,:2]).clamp(min=0)).prod(-1)
    bb=((b[...,2:]-b[...,:2]).clamp(min=0)).prod(-1)
    return inter/(aa+bb-inter+1e-8)

def giou(a,b):
    lt=torch.maximum(a[...,:2],b[...,:2]);rb=torch.minimum(a[...,2:],b[...,2:]);wh=(rb-lt).clamp(min=0)
    inter=wh[...,0]*wh[...,1]
    aa=(a[...,2:]-a[...,:2]).clamp(min=0).prod(-1);bb=(b[...,2:]-b[...,:2]).clamp(min=0).prod(-1)
    union=aa+bb-inter+1e-8;iou=inter/union
    clt=torch.minimum(a[...,:2],b[...,:2]);crb=torch.maximum(a[...,2:],b[...,2:]);carea=(crb-clt).clamp(min=0).prod(-1)+1e-8
    return iou-(carea-union)/carea

def decode(raw,anchors,image_size,num_classes):
    b,_,h,w=raw.shape
    z=raw.reshape(b,3,5+num_classes,h,w).permute(0,1,3,4,2)
    yy,xx=torch.meshgrid(torch.arange(h,device=raw.device),torch.arange(w,device=raw.device),indexing='ij')
    xy=(z[...,:2].sigmoid()+torch.stack((xx,yy),-1))/(torch.tensor([w,h],device=raw.device))
    wh=z[...,2:4].clamp(-10,10).exp()*torch.tensor(anchors,device=raw.device,dtype=raw.dtype).reshape(1,3,1,1,2)/image_size
    return z,torch.cat((xy,wh),-1)

class DetectionLoss(nn.Module):
    def __init__(self,cfg):super().__init__();self.cfg=cfg
    def forward(self,outputs,targets,penalty=None):
        objloss=targets.new_zeros(());clsloss=targets.new_zeros(());boxloss=targets.new_zeros(())
        # anchors ordered from small to large: finest head uses first three
        anchors=self.cfg.anchors
        all_anchors=torch.tensor(anchors,device=targets.device,dtype=targets.dtype)
        for level,raw in enumerate(outputs):
            b,_,h,w=raw.shape; a=anchors[level*3:(level+1)*3]
            z,boxes=decode(raw,a,self.cfg.image_size,self.cfg.num_classes)
            obj=torch.zeros_like(z[...,4]);cls=torch.zeros_like(z[...,5:]);positive=torch.zeros_like(obj,dtype=torch.bool)
            for i,t in enumerate(targets):
                label=int(t[0]);xywh=t[1:];
                if xywh[2]<=0 or xywh[3]<=0:continue
                pixel_wh=xywh[2:]*self.cfg.image_size
                intersection=torch.minimum(pixel_wh,all_anchors).prod(-1)
                union=pixel_wh.prod()+all_anchors.prod(-1)-intersection
                best=int((intersection/(union+1e-8)).argmax())
                if best//3!=level:continue
                anchor=best%3;cx=min(w-1,max(0,int(xywh[0]*w)));cy=min(h-1,max(0,int(xywh[1]*h)))
                positive[i,anchor,cy,cx]=True;obj[i,anchor,cy,cx]=1;cls[i,anchor,cy,cx,label]=1
                pred=xywh_to_xyxy(boxes[i,anchor,cy,cx]);gt=xywh_to_xyxy(xywh)
                boxloss=boxloss+1-giou(pred,gt)
            objloss=objloss+F.binary_cross_entropy_with_logits(z[...,4],obj,reduction='mean')
            if positive.any():clsloss=clsloss+F.binary_cross_entropy_with_logits(z[...,5:][positive],cls[positive],reduction='mean')
        loss=objloss+clsloss+boxloss/max(1,len(targets))
        if penalty is not None:loss=loss+penalty
        return loss,{'box':float(boxloss.detach()),'obj':float(objloss.detach()),'cls':float(clsloss.detach())}
