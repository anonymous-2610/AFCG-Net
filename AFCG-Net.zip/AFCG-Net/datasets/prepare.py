"""Build a manifest from class folders and corresponding binary lesion masks.

Expected: data/RAW/{BUSI,UDIAT,BrEaST}/{benign,malignant}/images/*.png
          data/RAW/{BUSI,UDIAT,BrEaST}/{benign,malignant}/masks/<same stem>.png
No patient grouping is inferred. Mask connected components are merged into one tight box.
"""
import argparse,csv,random
from pathlib import Path
import numpy as np
from PIL import Image

def create(root,dataset,out,seed=0):
    root=Path(root)/dataset;out=Path(out);out.mkdir(parents=True,exist_ok=True)
    entries=[]
    for cls,label in [('benign',0),('malignant',1)]:
        for image in sorted((root/cls/'images').glob('*')):
            if image.suffix.lower() not in ('.png','.jpg','.jpeg','.bmp'):continue
            mask=root/cls/'masks'/(image.stem+'.png')
            if not mask.exists():raise FileNotFoundError(f'Mask missing: {mask}')
            arr=np.asarray(Image.open(mask).convert('L'))>0
            ys,xs=np.where(arr)
            if not len(xs):continue
            entries.append(dict(image=str(image.resolve()),**{'class':label},x1=int(xs.min()),y1=int(ys.min()),x2=int(xs.max()+1),y2=int(ys.max()+1)))
    rng=random.Random(seed)
    splits={'train':[],'val':[],'test':[]}
    for label in (0,1):
        group=[r for r in entries if r['class']==label];rng.shuffle(group)
        n=len(group);a=int(round(n*.6));b=int(round(n*.2))
        for name,part in zip(splits,(group[:a],group[a:a+b],group[a+b:])):splits[name]+=part
    for name,rows in splits.items():
        with open(out/f'{name}.csv','w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=['image','class','x1','y1','x2','y2']);writer.writeheader();writer.writerows(rows)
        print(name,len(rows),{k:sum(r['class']==k for r in rows) for k in (0,1)})
    print('total',len(entries))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',default='data/RAW');p.add_argument('--dataset',required=True,choices=['BUSI','UDIAT','BrEaST']);p.add_argument('--out',default=None);a=p.parse_args()
    create(a.root,a.dataset,a.out or 'data/manifests/'+a.dataset)
