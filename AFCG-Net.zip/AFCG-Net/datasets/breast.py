"""Manifest-based BUSI/UDIAT/BrEaST detection dataset; no dataset is redistributed."""
import csv,random
from pathlib import Path
import numpy as np
from PIL import Image,ImageEnhance,ImageOps
import torch
from torch.utils.data import Dataset

class BreastDataset(Dataset):
    def __init__(self,manifest,root='.',image_size=416,augment=False):
        self.root=Path(root);self.image_size=image_size;self.augment=augment
        with open(manifest,newline='') as f:self.records=list(csv.DictReader(f))
        if not self.records:raise ValueError('Empty manifest '+str(manifest))
    def __len__(self):return len(self.records)
    def __getitem__(self,i):
        row=self.records[i];path=self.root/row['image']
        image=Image.open(path).convert('RGB')
        w,h=image.size
        x1,y1,x2,y2=[float(row[k]) for k in ('x1','y1','x2','y2')]
        if self.augment:
            if random.random()<0.5:
                image=ImageOps.mirror(image);x1,x2=w-x2,w-x1
            if random.random()<0.5:
                image=ImageOps.flip(image);y1,y2=h-y2,h-y1
            if random.random()<0.5:
                image=ImageEnhance.Contrast(image).enhance(random.uniform(0.8,1.2))
            if random.random()<0.5:
                image=ImageEnhance.Brightness(image).enhance(random.uniform(0.8,1.2))
        image=image.resize((self.image_size,self.image_size),Image.Resampling.BILINEAR)
        a=np.asarray(image,dtype=np.float32)/255.0
        a=(a-a.mean())/(a.std()+1e-6)
        xywh=[(x1+x2)/(2*w),(y1+y2)/(2*h),(x2-x1)/w,(y2-y1)/h]
        target=torch.tensor([int(row['class']),*xywh],dtype=torch.float32)
        return torch.from_numpy(a.copy()).permute(2,0,1),target,str(path)

def collate(batch):
    x,t,p=zip(*batch);return torch.stack(x),torch.stack(t),list(p)
