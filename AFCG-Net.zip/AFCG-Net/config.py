"""Central reproducible experiment configuration."""
from dataclasses import dataclass, asdict
from pathlib import Path
import json

@dataclass
class Config:
    data_root: str = 'data'
    dataset: str = 'BUSI'
    output_dir: str = 'runs/afcg_busi'
    image_size: int = 416
    train_fraction: float = 0.60
    val_fraction: float = 0.20
    test_fraction: float = 0.20
    seed: int = 0
    epochs: int = 500
    batch_size: int = 8
    workers: int = 4
    lr: float = 0.002
    momentum: float = 0.9
    weight_decay: float = 0.0005
    lr_milestones: tuple = (300, 400)
    lr_gamma: float = 0.1
    pretrained: bool = False
    backbone: str = 'resnet101'
    num_classes: int = 2
    names: tuple = ('benign', 'malignant')
    pool_stride: int = 2
    k_min: int = 4
    k_max: int = 16
    cross_k: int = 3
    gat_layers: int = 2
    gat_heads: int = 4
    frequency_window: int = 5
    dct_coefficients: int = 9
    position_dim: int = 16
    position_temperature: float = 100.0
    gumbel_tau_start: float = 1.0
    gumbel_tau_end: float = 0.1
    sparsity_lambda: float = 0.01
    channel_reduction: int = 16
    confidence: float = 0.25
    nms_iou: float = 0.5
    max_detections: int = 100
    anchors: tuple = ((10,13),(16,30),(33,23),(30,61),(62,45),(59,119),(116,90),(156,198),(373,326))
    multi_scale_interval: int = 10
    model: str = 'afcg'
    device: str = 'cuda'
    def save(self,path):
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        Path(path).write_text(json.dumps(asdict(self),indent=2))
    @classmethod
    def load(cls,path):
        d=json.loads(Path(path).read_text())
        return cls(**d)
