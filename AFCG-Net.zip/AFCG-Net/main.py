"""Train, evaluate and visualize breast ultrasound detectors."""
import argparse,json,time
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from config import Config
from utils.seed import seed_everything
from datasets.breast import BreastDataset,collate
from baselines.factory import build_model
from algorithms.yolo_loss import DetectionLoss
from utils.evaluate import run_evaluation
from utils.visualization import plot_training

def arguments():
    p=argparse.ArgumentParser()
    p.add_argument('--mode',choices=['train','evaluate','visualize'],default='train')
    p.add_argument('--dataset',choices=['BUSI','UDIAT','BrEaST'],default='BUSI')
    p.add_argument('--model',choices=['afcg','ggsan','dganet','framework'],default='afcg')
    p.add_argument('--manifest-dir',default=None)
    p.add_argument('--data-root',default='.')
    p.add_argument('--output-dir',default=None)
    p.add_argument('--checkpoint',default=None)
    p.add_argument('--epochs',type=int,default=500)
    p.add_argument('--batch-size',type=int,default=8)
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--device',default='cuda')
    return p.parse_args()

def train(cfg,manifest):
    out=Path(cfg.output_dir);out.mkdir(parents=True,exist_ok=True);cfg.save(out/'config.json')
    seed_everything(cfg.seed)
    device=torch.device(cfg.device if cfg.device=='cpu' or torch.cuda.is_available() else 'cpu')
    train_ds=BreastDataset(manifest/'train.csv',cfg.data_root,cfg.image_size,augment=True)
    val_ds=BreastDataset(manifest/'val.csv',cfg.data_root,cfg.image_size)
    train_dl=DataLoader(train_ds,batch_size=cfg.batch_size,shuffle=True,num_workers=cfg.workers,collate_fn=collate)
    val_dl=DataLoader(val_ds,batch_size=cfg.batch_size,shuffle=False,num_workers=cfg.workers,collate_fn=collate)
    model=build_model(cfg).to(device);loss_fn=DetectionLoss(cfg)
    opt=torch.optim.SGD(model.parameters(),lr=cfg.lr,momentum=cfg.momentum,weight_decay=cfg.weight_decay)
    scheduler=torch.optim.lr_scheduler.MultiStepLR(opt,milestones=list(cfg.lr_milestones),gamma=cfg.lr_gamma)
    best=-float('inf');history=[]
    for epoch in range(cfg.epochs):
        start=time.time();model.train();total=0.;tau=cfg.gumbel_tau_start+(cfg.gumbel_tau_end-cfg.gumbel_tau_start)*epoch/max(1,cfg.epochs-1)
        for images,targets,_ in train_dl:
            images=images.to(device);targets=targets.to(device)
            opt.zero_grad(set_to_none=True)
            outs,penalty,_=model(images,tau=tau)
            loss,_=loss_fn(outs,targets,penalty)
            loss.backward();opt.step();total+=float(loss.detach())
        scheduler.step()
        model.eval();val_total=0.
        with torch.no_grad():
            for images,targets,_ in val_dl:
                outs,penalty,_=model(images.to(device),tau=tau)
                loss,_=loss_fn(outs,targets.to(device),penalty)
                val_total+=float(loss)
        # validation fitness based on detection AP; never use test for checkpoint selection
        metrics=run_evaluation(model,cfg,manifest/'val.csv',out/'validation',visualize=False)
        fitness=metrics['mAP50']
        item=dict(epoch=epoch+1,train_loss=total/max(1,len(train_dl)),val_loss=val_total/max(1,len(val_dl)),val_mAP50=fitness,seconds=round(time.time()-start,2))
        history.append(item);(out/'history.json').write_text(json.dumps(history,indent=2))
        print(json.dumps(item),flush=True)
        state={'model':model.state_dict(),'optimizer':opt.state_dict(),'scheduler':scheduler.state_dict(),'epoch':epoch+1,'config':cfg.__dict__}
        torch.save(state,out/'last.pt')
        if fitness>best:best=fitness;torch.save(state,out/'best.pt')
    plot_training(history,out/'training_curves.png')
    state=torch.load(out/'best.pt',map_location=device,weights_only=False)
    model.load_state_dict(state['model'])
    result=run_evaluation(model,cfg,manifest/'test.csv',out/'test',visualize=True)
    print('TEST:',json.dumps(result,indent=2))

def main():
    args=arguments();cfg=Config(dataset=args.dataset,model=args.model,epochs=args.epochs,batch_size=args.batch_size,workers=args.workers,device=args.device,data_root=args.data_root,output_dir=args.output_dir or f'runs/{args.dataset.lower()}_{args.model}')
    manifest=Path(args.manifest_dir or f'data/manifests/{args.dataset}')
    if args.mode=='train':train(cfg,manifest);return
    if not args.checkpoint:raise ValueError('--checkpoint is required for evaluation')
    state=torch.load(args.checkpoint,map_location='cpu',weights_only=False)
    cfg=Config(**state['config']);cfg.data_root=args.data_root;cfg.workers=args.workers
    model=build_model(cfg);model.load_state_dict(state['model'])
    device=args.device if args.device=='cpu' or torch.cuda.is_available() else 'cpu';model.to(device)
    output=Path(args.output_dir or f'runs/eval_{cfg.dataset}_{cfg.model}')
    result=run_evaluation(model,cfg,manifest/'test.csv',output,visualize=True)
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
