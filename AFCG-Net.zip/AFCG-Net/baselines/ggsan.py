from models.detector import AFCGNet

def build(cfg):
    return AFCGNet(cfg,variant='ggsan')
