"""Trainable baseline selection.

The native variants are controlled architecture ablations. External YOLOv12,
YOLOv8-GHOST-P2, and RT-DETR are supported by separately installed upstream
implementations; no claim is made that a stock model is a faithful reimplementation.
"""
from models.detector import AFCGNet

def build_model(cfg):
    if cfg.model in ('afcg','ggsan','dganet','framework'):
        return AFCGNet(cfg,variant=cfg.model)
    raise ValueError(f'External baseline {cfg.model} requires its original implementation; see README. Native choices: afcg, ggsan, dganet, framework')
