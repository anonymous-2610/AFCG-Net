# AFCG-Net

Trainable breast ultrasound lesion detection repository with frequency-aware graph attention, cross-scale feature connections, adaptive neighborhood size, and a three-head anchor detector.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pytest -q
```

## Dataset layout

No ultrasound images are included. Obtain the BUSI, UDIAT, and BrEaST collections from their respective owners and arrange them as follows:

```
data/RAW/BUSI/benign/images/<id>.png
                         masks/<id>.png
              malignant/images/<id>.png
                        masks/<id>.png
```

Use the same arrangement for `UDIAT` and `BrEaST`. Each image must have a same-stem binary mask. Images with no lesions are excluded. The preparation utility merges all positive mask pixels into one bounding box. Review ambiguous/multi-lesion cases manually.

```bash
python -m datasets.prepare --root data/RAW --dataset BUSI
python -m datasets.prepare --root data/RAW --dataset UDIAT
python -m datasets.prepare --root data/RAW --dataset BrEaST
```

Each CSV contains image path, class, and tight bounding-box coordinates. The default split is seeded, class-stratified 60/20/20 at image level. No patient-disjoint guarantee is made for BUSI or UDIAT. The prepared manifest is saved separately from raw images. Inspect its counts before training.

## Train

```bash
python main.py --mode train --dataset BUSI --model afcg --device cuda
python main.py --mode train --dataset UDIAT --model afcg --device cuda
python main.py --mode train --dataset BrEaST --model afcg --device cuda
```

Native comparison variants use `--model ggsan`, `--model dganet`, or `--model framework` and the same training command. They are simplified controlled variants; they should not be represented as bit-for-bit reproductions of third-party implementations. The native DGANet variant does not implement the original Gaussian-prior bilateral attention and must not be used to claim an exact DGANet reproduction.

## Evaluate and visualize

```bash
python main.py --mode evaluate --dataset BUSI --checkpoint runs/busi_afcg/best.pt --device cuda
python main.py --mode visualize --dataset BUSI --checkpoint runs/busi_afcg/best.pt --device cuda
```

Outputs are computed from the trained checkpoint and test images: `metrics.json`, `class_ap.png`, `predictions/*.png`, and `training_curves.png`. No predetermined scores are injected. AP uses 101-point interpolation; mean AP uses both benign and malignant classes, and mAP@0.5:0.95 averages 10 IoU thresholds. Inference confidence defaults to 0.25, NMS IoU to 0.5.

## Configuration

The default schedule is 500 epochs, SGD momentum 0.9, weight decay 0.0005, batch size 8, initial LR 0.002, LR reductions at 300 and 400, 416×416 inputs, 9 anchors, seed 0, no pretrained weights. GAT has two layers and four heads, FAA uses 5×5 DCT windows with nine coefficients, adaptive neighbors range from 4 to 16, and cross-scale fusion uses three neighbors.

**Implementation notes:** The exact original source code, dataset partitions, anchor centroids, checkpoint-fitness weights, augmentation magnitudes, and several architectural internals were not available. The included implementation makes documented choices where possible, and explicitly uses practical approximations elsewhere. Default anchors are common YOLO anchors, not verified dataset-specific k-means anchors. For exact experimental replication, replace these with anchors fitted to training annotations, verify split files and augmentations, and obtain original baseline implementations. Current cross-scale fusion uses local spatial alignment rather than a full graph with the exact published cross-scale edge formulation. A full dense graph score computation can be memory-intensive; use the V100 configuration with care. Evaluation must be performed on real data; no metrics are supplied in advance.

## Files

- `models/detector.py`: ResNet-101 backbone, attention and detection heads
- `models/frequency.py`: learned local DCT descriptor
- `models/graph.py`: adaptive graph and cross-scale fusion
- `models/attention.py`: global channel attention
- `algorithms/yolo_loss.py`: bounding-box, objectness and class losses
- `datasets/prepare.py`, `datasets/breast.py`: manifests and loading
- `utils/metrics.py`, `utils/evaluate.py`, `utils/visualization.py`: evaluation and figures
- `baselines/`: native comparison variants
- `main.py`: train, evaluate, visualize entry point

This is a functional research starting point, not a verified exact reproduction. Check architecture and evaluation details against your training code before publishing quantitative comparisons.
