import torch
from algorithms.yolo_loss import box_iou,giou,decode
from models.frequency import FrequencyDescriptor

def test_iou():
    a=torch.tensor([0.,0.,1.,1.]);assert abs(float(box_iou(a,a))-1)<1e-5
    assert abs(float(giou(a,a))-1)<1e-5

def test_frequency():
    model=FrequencyDescriptor(8,5,9)
    assert model(torch.randn(2,8,4,4)).shape==(2,16,2)

def test_decode():
    z,b=decode(torch.zeros(1,21,13,13),[(10,13),(16,30),(33,23)],416,2)
    assert b.shape==(1,3,13,13,4)
