"""ResNet-101 / YOLOv3-style three-scale anchor detector."""
import torch
from torch import nn
from torch.nn import functional as F
from torchvision.models import resnet101
from .graph import GraphScale,CrossScaleFusion
from .attention import GCAM

class ConvBNAct(nn.Sequential):
    def __init__(self,a,b,k=3):
        super().__init__(nn.Conv2d(a,b,k,padding=k//2,bias=False),nn.BatchNorm2d(b),nn.LeakyReLU(0.1,inplace=True))

class AFCGNet(nn.Module):
    def __init__(self,cfg, variant='afcg'):
        super().__init__();self.cfg=cfg;self.variant=variant
        self.backbone=resnet101(weights=None)
        self.stem=nn.Sequential(self.backbone.conv1,self.backbone.bn1,self.backbone.relu,self.backbone.maxpool)
        self.c1=self.backbone.layer1;self.c2=self.backbone.layer2;self.c3=self.backbone.layer3;self.c4=self.backbone.layer4
        channels=[512,1024,2048]
        self.gcam=nn.ModuleList([GCAM(c,cfg.channel_reduction) for c in channels])
        self.graph=nn.ModuleList([GraphScale(c,cfg) for c in channels])
        self.cross=CrossScaleFusion(channels,cfg.cross_k)
        self.lateral=nn.ModuleList([ConvBNAct(c,256,1) for c in channels])
        self.fuse4=ConvBNAct(512,256)
        self.fuse3=ConvBNAct(512,256)
        self.heads=nn.ModuleList([nn.Sequential(ConvBNAct(256,256),nn.Conv2d(256,3*(5+cfg.num_classes),1)) for _ in range(3)])
    def forward(self,x,tau=0.1):
        z=self.stem(x);z=self.c1(z);p3=self.c2(z);p4=self.c3(p3);p5=self.c4(p4)
        features=[p3,p4,p5];penalty=x.new_zeros(());diagnostics=[]
        if self.variant in ('afcg','ggsan','dganet'):
            enhanced=[]
            for f,g,graph in zip(features,self.gcam,self.graph):
                out=f+g(f)
                if self.variant in ('afcg','ggsan'):
                    gs,degree,diag=graph(f,tau)
                    out=out+gs;penalty=penalty+degree*self.cfg.sparsity_lambda if self.variant=='afcg' else penalty
                    diagnostics.append(diag)
                enhanced.append(out)
            features=enhanced
        if self.variant=='afcg':
            cross=self.cross(features)
            features=[a+b for a,b in zip(features,cross)]
        a,b,c=[layer(f) for layer,f in zip(self.lateral,features)]
        b=self.fuse4(torch.cat((b,F.interpolate(c,size=b.shape[-2:],mode='nearest')),1))
        a=self.fuse3(torch.cat((a,F.interpolate(b,size=a.shape[-2:],mode='nearest')),1))
        outs=[head(f) for head,f in zip(self.heads,[a,b,c])]
        return outs,penalty,diagnostics
