"""Differentiable local DCT-II descriptors computed on backbone feature maps."""
import math
import torch
from torch import nn
from torch.nn import functional as F

def zigzag_indices(n, count):
    result=[]
    for diag in range(2*n-1):
        pairs=[(i,diag-i) for i in range(n) if 0<=diag-i<n]
        if diag%2==0: pairs.reverse()
        result.extend(pairs)
    return [i*n+j for i,j in result[:count]]

class FrequencyDescriptor(nn.Module):
    def __init__(self, channels, window=5, coefficients=9):
        super().__init__()
        if window%2!=1: raise ValueError('DCT window must be odd')
        if coefficients>window**2: raise ValueError('Too many coefficients')
        self.window=window; self.coefficients=coefficients
        basis=torch.empty(window,window)
        for u in range(window):
            for x in range(window):
                basis[u,x]=math.sqrt((1 if u==0 else 2)/window)*math.cos(math.pi*(2*x+1)*u/(2*window))
        filters=[]
        for idx in zigzag_indices(window,coefficients):
            u,v=divmod(idx,window)
            filters.append(torch.outer(basis[u],basis[v]))
        self.register_buffer('filters',torch.stack(filters))
        self.proj=nn.Linear(channels*coefficients,max(1,channels//4))
    def forward(self,x):
        # x: B,C,H,W, return B,N,C/4; all windows extracted by grouped conv.
        b,c,h,w=x.shape
        kernels=self.filters[:,None].repeat(c,1,1,1).reshape(c*self.coefficients,1,self.window,self.window)
        y=F.conv2d(x,kernels,padding=self.window//2,groups=c)
        y=y.permute(0,2,3,1).reshape(b,h*w,c*self.coefficients)
        return self.proj(y)
