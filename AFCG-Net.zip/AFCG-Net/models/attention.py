import torch
from torch import nn

class GCAM(nn.Module):
    def __init__(self,channels,reduction=16):
        super().__init__(); hidden=max(1,channels//reduction)
        self.spatial=nn.Conv2d(channels,1,1)
        self.channel=nn.Sequential(nn.Linear(channels,hidden),nn.ReLU(inplace=True),nn.Linear(hidden,channels),nn.Sigmoid())
    def forward(self,x):
        b,c,h,w=x.shape
        attention=self.spatial(x).flatten(2).softmax(-1)
        z=(x.flatten(2)*attention).sum(-1)
        return x*self.channel(z).view(b,c,1,1)
