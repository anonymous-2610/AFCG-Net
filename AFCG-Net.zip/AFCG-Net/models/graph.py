"""Frequency-aware graph affinity, learned degree, and cross-resolution message passing."""
import math
import torch
from torch import nn
from torch.nn import functional as F
from .frequency import FrequencyDescriptor

class GraphScale(nn.Module):
    def __init__(self,channels, cfg):
        super().__init__()
        self.channels=channels; self.cfg=cfg
        self.freq=FrequencyDescriptor(channels,cfg.frequency_window,cfg.dct_coefficients)
        d=max(1,channels//4)
        self.query=nn.Linear(channels,d); self.key=nn.Linear(channels,d)
        self.affinity=nn.Sequential(nn.Linear(3*d+2*cfg.position_dim,max(8,d//2)),nn.LeakyReLU(0.2),nn.Linear(max(8,d//2),1))
        self.gate=nn.Sequential(nn.Linear(channels,max(16,d)),nn.ReLU(),nn.Linear(max(16,d),cfg.k_max-cfg.k_min+1))
        self.attn=nn.ModuleList([nn.MultiheadAttention(channels,cfg.gat_heads,batch_first=True) for _ in range(cfg.gat_layers)])
        self.out=nn.Conv2d(channels,channels,1)
    def positional(self,coords):
        # coords: N,2, sinusoidal features for row/column.
        d=self.cfg.position_dim
        inv=torch.pow(torch.tensor(self.cfg.position_temperature,device=coords.device,dtype=coords.dtype),-torch.arange(d//2,device=coords.device,dtype=coords.dtype)*2/d)
        parts=[]
        for axis in range(2):
            z=coords[:,axis,None]*inv[None,:]
            parts.append(torch.stack((z.sin(),z.cos()),-1).flatten(-2))
        return torch.cat(parts,-1)
    def forward(self,x,tau=0.1):
        b,c,h,w=x.shape
        pooled=F.avg_pool2d(x,2,ceil_mode=True)
        hh,ww=pooled.shape[-2:]; n=hh*ww
        f=pooled.flatten(2).transpose(1,2)
        # Compute DCT at graph node resolution using corresponding pooled windows.
        phi=self.freq(pooled)
        coords=torch.stack(torch.meshgrid(torch.arange(hh,device=x.device),torch.arange(ww,device=x.device),indexing='ij'),-1).reshape(-1,2).float()
        pe=self.positional(coords)
        q=self.query(f); k=self.key(f)
        # pairwise affinities are computed in chunks to limit peak allocation.
        logits=self.gate(f)
        if self.training:
            probs=F.gumbel_softmax(logits,tau=tau,hard=True,dim=-1)
            soft=F.softmax(logits/tau,dim=-1)
            sizes=(probs*torch.arange(self.cfg.k_min,self.cfg.k_max+1,device=x.device)).sum(-1).long()
        else:
            soft=F.softmax(logits,dim=-1)
            sizes=logits.argmax(-1)+self.cfg.k_min
        expected=(soft*torch.arange(self.cfg.k_min,self.cfg.k_max+1,device=x.device)).sum(-1).mean()
        kmax=min(self.cfg.k_max,n-1)
        # Build directed sparse neighbors from semantic, relative spatial and DCT descriptors.
        neighbors=[]; masks=[]
        for start in range(0,n,128):
            end=min(n,start+128); t=end-start
            pos=(pe[start:end,None,:]-pe[None,:,:]).expand(t,n,-1)
            z=torch.cat((q[:,start:end,None,:].expand(b,t,n,-1),k[:,None,:,:].expand(b,t,n,-1),pos[None].expand(b,-1,-1,-1),phi[:,start:end,None,:]-phi[:,None,:,:]),-1)
            score=self.affinity(z).squeeze(-1)
            ids=torch.arange(start,end,device=x.device)
            score[:,torch.arange(t,device=x.device),ids]=-1e9
            ix=score.topk(kmax,-1).indices
            neighbors.append(ix)
            masks.append(torch.arange(kmax,device=x.device)[None,None,:]<sizes[:,start:end,None])
        idx=torch.cat(neighbors,1); active=torch.cat(masks,1)
        # Attention over each node's sparse neighborhood; query included as token zero.
        selected=f[torch.arange(b,device=x.device)[:,None,None],idx]
        tokens=torch.cat((f[:,:,None,:],selected),dim=2).reshape(b*n,1+kmax,c)
        keymask=torch.cat((torch.ones(b,n,1,device=x.device,dtype=torch.bool),active),-1).reshape(b*n,1+kmax)
        query=tokens[:,:1,:]
        for attn in self.attn:
            update,_=attn(query,tokens,tokens,key_padding_mask=~keymask,need_weights=False)
            query=query+update
            tokens=torch.cat((query,tokens[:,1:,:]),1)
        result=query.reshape(b,n,c).transpose(1,2).reshape(b,c,hh,ww)
        result=F.interpolate(result,size=(h,w),mode='bilinear',align_corners=False)
        return self.out(result),expected,{'mean_k':sizes.float().mean().detach()}

class CrossScaleFusion(nn.Module):
    """Directed top-k cross-scale connections among spatially overlapping nodes.

    Coarse-to-fine and fine-to-coarse neighborhoods are formed on aligned feature grids.
    """
    def __init__(self,channels,cross_k=3):
        super().__init__();self.cross_k=cross_k
        self.align=nn.ModuleList([nn.Conv2d(ch,channels,1) for ch in channels])
        self.queries=nn.ModuleList([nn.Conv2d(channels,channels//4,1) for _ in channels])
        self.keys=nn.ModuleList([nn.Conv2d(channels,channels//4,1) for _ in channels])
        self.project=nn.ModuleList([nn.Conv2d(channels,channels,1) for _ in channels])
    def forward(self,features):
        aligned=[layer(x) for layer,x in zip(self.align,features)]
        result=[]
        for i,source in enumerate(aligned):
            b,c,h,w=source.shape
            acc=source
            for j,other in enumerate(aligned):
                if i==j: continue
                # Correspondence region: nearest source grid cell and its local neighbors.
                # Use local unfold neighborhoods rather than dense global graph.
                target=F.interpolate(other,size=(h,w),mode='bilinear',align_corners=False)
                patches=F.unfold(target,kernel_size=3,padding=1).reshape(b,c,9,h*w).permute(0,3,2,1)
                query=self.queries[i](source).flatten(2).transpose(1,2)
                # channel-aligned keys via the target projection
                keypatch=F.unfold(self.keys[j](target),3,padding=1).reshape(b,c//4,9,h*w).permute(0,3,2,1)
                score=(query[:,:,None,:]*keypatch).sum(-1)/math.sqrt(c//4)
                top=score.topk(min(self.cross_k,9),-1).indices
                gathered=patches.gather(2,top[:,:,:,None].expand(-1,-1,-1,c))
                weights=score.gather(2,top).softmax(-1)
                msg=(gathered*weights[:,:,:,None]).sum(2).transpose(1,2).reshape(b,c,h,w)
                acc=acc+msg/2
            result.append(self.project[i](acc))
        return result
