"""Detection AP uses dataset-level class-wise precision-recall integration."""
import numpy as np
import torch
from torchvision.ops import nms
from algorithms.yolo_loss import decode,xywh_to_xyxy,box_iou

def predict(outputs,cfg,confidence=None):
    threshold=cfg.confidence if confidence is None else confidence
    batch=outputs[0].shape[0];items=[[] for _ in range(batch)]
    for level,raw in enumerate(outputs):
        z,xywh=decode(raw,cfg.anchors[level*3:(level+1)*3],cfg.image_size,cfg.num_classes)
        scores=z[...,4:5].sigmoid()*z[...,5:].sigmoid()
        boxes=xywh_to_xyxy(xywh).reshape(batch,-1,4).clamp(0,1)
        scores=scores.reshape(batch,-1,cfg.num_classes)
        for i in range(batch):
            for cls in range(cfg.num_classes):
                keep=scores[i,:,cls]>=threshold
                if keep.any():
                    bb=boxes[i,keep];ss=scores[i,keep,cls];cc=torch.full_like(ss,cls,dtype=torch.long)
                    items[i].append(torch.cat((bb,ss[:,None],cc[:,None]),-1))
    result=[]
    for parts in items:
        if not parts:result.append(torch.zeros((0,6),device=outputs[0].device));continue
        a=torch.cat(parts)
        keep=nms(a[:,:4]+a[:,5:6]*2,a[:,4],cfg.nms_iou)[:cfg.max_detections]
        result.append(a[keep])
    return result

def average_precision(recall,precision):
    mrec=np.r_[0.,recall,1.];mpre=np.r_[1.,precision,0.]
    mpre=np.maximum.accumulate(mpre[::-1])[::-1]
    return float(np.trapezoid(np.interp(np.linspace(0,1,101),mrec,mpre),np.linspace(0,1,101)))

def evaluate_records(records,num_classes=2,iou_thresholds=None):
    if iou_thresholds is None:iou_thresholds=np.arange(.5,.951,.05)
    result={};aps=[]
    for threshold in iou_thresholds:
        per=[]
        for cls in range(num_classes):
            gt_count=sum(int(int(t[0])==cls) for _,t in records)
            scored=[]
            for predictions,target in records:
                gt=xywh_to_xyxy(target[1:].unsqueeze(0)).squeeze(0) if int(target[0])==cls else None
                selected=predictions[predictions[:,5].long()==cls]
                for pred in selected:scored.append((float(pred[4]),pred[:4],gt,id(target)))
            scored.sort(key=lambda z:-z[0]);used=set();tp=[];fp=[]
            for score,box,gt,uid in scored:
                match=gt is not None and uid not in used and float(box_iou(box,gt))>=threshold
                tp.append(int(match));fp.append(int(not match))
                if match:used.add(uid)
            if gt_count:
                cumtp=np.cumsum(tp);cumfp=np.cumsum(fp)
                precision=cumtp/(cumtp+cumfp+1e-9);recall=cumtp/gt_count
                ap=average_precision(recall,precision) if len(tp) else 0.
            else:ap=float('nan')
            per.append(ap)
        aps.append(float(np.nanmean(per)))
        if abs(threshold-.5)<1e-6:
            result['ap_per_class']={str(i):float(v) for i,v in enumerate(per)}
            result['mAP50']=aps[-1]
    result['mAP50_95']=float(np.mean(aps))
    # Operating point precision/recall at configured confidence and IoU .5
    tp=fp=fn=0
    for predictions,target in records:
        target_cls=int(target[0]);gt=xywh_to_xyxy(target[1:].unsqueeze(0)).squeeze(0);matched=False
        for pred in sorted(predictions,key=lambda x:-float(x[4])):
            ok=(not matched and int(pred[5])==target_cls and float(box_iou(pred[:4],gt))>=.5)
            tp+=int(ok);fp+=int(not ok);matched|=ok
        fn+=int(not matched)
    result['precision']=tp/max(tp+fp,1);result['recall']=tp/max(tp+fn,1)
    result['f1']=2*result['precision']*result['recall']/max(result['precision']+result['recall'],1e-9)
    result.update(tp=tp,fp=fp,fn=fn)
    return result
