import json
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from datasets.breast import BreastDataset,collate
from utils.metrics import predict,evaluate_records
from utils.visualization import draw_predictions,plot_class_ap

@torch.no_grad()
def run_evaluation(model,cfg,manifest,output_dir,visualize=True):
    model.eval();device=next(model.parameters()).device
    loader=DataLoader(BreastDataset(manifest,cfg.data_root,cfg.image_size),batch_size=cfg.batch_size,shuffle=False,num_workers=cfg.workers,collate_fn=collate)
    records=[];visuals=[]
    for images,targets,paths in loader:
        outputs,_,_=model(images.to(device))
        detections=predict(outputs,cfg,confidence=0.001)
        displays=predict(outputs,cfg,confidence=cfg.confidence)
        for det,display,t,path in zip(detections,displays,targets,paths):
            records.append((det.cpu(),t))
            if len(visuals)<20:visuals.append((display.cpu(),t,path))
    metrics=evaluate_records(records,cfg.num_classes)
    # precision/recall must use the operational confidence, not low-threshold AP candidates
    operational=[(d[d[:,4]>=cfg.confidence],t) for d,t in records]
    op=evaluate_records(operational,cfg.num_classes)
    for key in ('precision','recall','f1','tp','fp','fn'):metrics[key]=op[key]
    output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    (output_dir/'metrics.json').write_text(json.dumps(metrics,indent=2))
    if visualize:
        plot_class_ap(metrics,output_dir/'class_ap.png',cfg.names)
        for i,(det,t,path) in enumerate(visuals):draw_predictions(path,det,t,output_dir/'predictions'/f'{i:04d}.png',cfg.names)
    return metrics
