"""Prediction overlays, PR summary bars, confusion and learning curves."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image,ImageDraw
import numpy as np

def draw_predictions(image_path,predictions,target,output,names=('benign','malignant')):
    image=Image.open(image_path).convert('RGB');w,h=image.size
    draw=ImageDraw.Draw(image)
    x,y,bw,bh=target[1:].tolist();gt=((x-bw/2)*w,(y-bh/2)*h,(x+bw/2)*w,(y+bh/2)*h)
    draw.rectangle(gt,outline='#20c55a',width=3)
    for p in predictions:
        x1,y1,x2,y2,score,cls=p.tolist()
        draw.rectangle((x1*w,y1*h,x2*w,y2*h),outline='#e53935',width=3)
        draw.text((x1*w,y1*h),f'{names[int(cls)]} {score:.2f}',fill='#e53935')
    Path(output).parent.mkdir(parents=True,exist_ok=True);image.save(output)

def plot_training(history,out):
    fig,ax=plt.subplots(figsize=(8,5))
    for key in ('train_loss','val_loss','val_mAP50'):
        values=[x.get(key,float('nan')) for x in history]
        ax.plot(range(1,len(values)+1),values,label=key)
    ax.set(xlabel='Epoch',ylabel='Value',title='Training and validation');ax.legend();fig.tight_layout();fig.savefig(out,dpi=200);plt.close(fig)

def plot_class_ap(metrics,out,names=('benign','malignant')):
    fig,ax=plt.subplots(figsize=(6,4))
    vals=[metrics['ap_per_class'][str(i)] for i in range(len(names))]
    ax.bar(names,vals);ax.set_ylim(0,1);ax.set(ylabel='AP@0.5',title='Class-wise detection accuracy')
    fig.tight_layout();fig.savefig(out,dpi=200);plt.close(fig)
